//
// import 'package:flutter/material.dart';
// import 'package:firebase_core/firebase_core.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:lildairy/screens/AppIntroductionScreen.dart';
// import 'package:lildairy/screens/HomeScreen.dart';
// import 'package:lildairy/screens/login.dart';
// // import 'package:lildairy/test.dart';
// // import 'package:lildairy/screens/LoginScreen.dart'; // Ensure you have the right import path
//
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp(); // Initialize Firebase
//   runApp(const MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'LilDairy',
//       theme: ThemeData(primaryColor: const Color(0xFF81D4FA)),
//       home: AuthWrapper(), // Use a wrapper to check user state
//     );
//   }
// }
//
// class AuthWrapper extends StatelessWidget {
//   const AuthWrapper({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     User? user = FirebaseAuth.instance.currentUser;
//       // return  const NotesHomeScreen();
//
//     // Check if user is logged in
//     if (user != null) {
//       // If user is logged in, navigate to HomeScreen
//       return  const NotesHomeScreen();
//       // return  const AppIntroductionScreen();
//     } else {
//       // If user is not logged in, show LoginScreen
//       return const LoginScreen();
//     }
//   }
// }

// Version code 1 has already been used. Try another version code.
// Your APK or Android App Bundle needs to have the package name com.playconsole.lildiary.
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:lildairy/test.dart';
import 'package:permission_handler/permission_handler.dart'; // Import permission handler
import 'package:lildairy/screens/AppIntroductionScreen.dart';
import 'package:lildairy/screens/HomeScreen.dart';
import 'package:lildairy/screens/login.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Initialize Firebase
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LilDairy',
      theme: ThemeData(primaryColor: const Color(0xFF81D4FA)),
      home: const AuthWrapper(), // Use a wrapper to check user state
    );
  }
}

class AuthWrapper extends StatefulWidget {
  const AuthWrapper({super.key});

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  @override
  void initState() {
    super.initState();
    requestStoragePermission(); // Request storage permission on app start
  }

  Future<void> requestStoragePermission() async {
    var status = await Permission.storage.status;
    if (!status.isGranted) {
      status = await Permission.storage.request();
      if (!status.isGranted) {
        // You can show an alert here if needed
        throw Exception("Storage permission denied.");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    User? user = FirebaseAuth.instance.currentUser;

    // return PermissionHandlerWidget();
    // Check if user is logged in
    if (user != null) {
      // If user is logged in, navigate to HomeScreen
      return const NotesHomeScreen();
    } else {
      // If user is not logged in, show LoginScreen
      return const LoginScreen();
    }
  }
}
