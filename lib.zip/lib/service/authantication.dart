import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthMethod {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Sign Up User
  Future<String> signupUser({
    required String email,
    required String password,
    required String name,
  }) async {
    String res = "Some error occurred";
    try {
      if (email.isNotEmpty && password.isNotEmpty && name.isNotEmpty) {
        // Register user in Firebase Auth with email and password
        UserCredential cred = await _auth.createUserWithEmailAndPassword(
          email: email,
          password: password,
        );

        // Add user to Firestore database
        await _firestore.collection("users").doc(cred.user!.uid).set({
          'name': name,
          'uid': cred.user!.uid,
          'email': email,
        });

        res = "success";
      } else {
        res = "Please fill in all the fields.";
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'email-already-in-use') {
        res = "Email is already in use. Please log in.";
      } else if (e.code == 'invalid-email') {
        res = "The email address is not valid.";
      } else if (e.code == 'weak-password') {
        res = "The password is too weak.";
      } else {
        res = "Something went wrong. Please try again.";
      }
    } catch (err) {
      res = "Error: ${err.toString()}";
    }
    return res;
  }

  // Log In User
  Future<String> loginUser({
    required String email,
    required String password,
  }) async {
    String res = "Some error occurred";
    try {
      if (email.isNotEmpty && password.isNotEmpty) {
        // Logging in user with email and password
        await _auth.signInWithEmailAndPassword(
          email: email,
          password: password,
        );
        res = "success";
      } else {
        res = "Please enter all the fields.";
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        res = "No user found with this email. Please sign up.";
      } else if (e.code == 'wrong-password') {
        res = "Incorrect password. Please try again.";
      } else if (e.code == 'invalid-email') {
        res = "Invalid email address.";
      } else {
        res = "Something went wrong. Please try again.";
      }
    } catch (err) {
      res = "Error: ${err.toString()}";
    }
    return res;
  }

  // Sign Out User
  Future<void> signOut() async {
    try {
      await _auth.signOut();
    } catch (err) {
      print("Error signing out: ${err.toString()}");
    }
  }
}
